.. LAVIS documentation master file, created by
   sphinx-quickstart on Sun Jul 31 10:32:27 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to LAVIS's documentation!
=================================

.. toctree::
   :maxdepth: 1
   :caption: Introduction

   intro


.. toctree::
   :maxdepth: 1
   :caption: Getting Started

   getting_started


..    :maxdepth: 1
..    :caption: Advanced Training

..    advanced_training


.. toctree::
   :maxdepth: 2
   :caption: Advanced Usage

   benchmark
   tutorial


.. Documentations
.. ===================


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
